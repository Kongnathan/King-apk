import type { Project, Stat, TimelineEvent, MarketplaceItem } from './types';

export const recentProjects: Project[] = [
  { id: '1', name: 'Kingdom of Kongo Documentary', type: 'video', thumbnail: '🎬', updatedAt: '2 hours ago', progress: 75 },
  { id: '2', name: 'Boma City Aerial Shots', type: 'image', thumbnail: '📸', updatedAt: '5 hours ago', progress: 100 },
  { id: '3', name: 'Congo River Soundtrack', type: 'audio', thumbnail: '🎵', updatedAt: 'Yesterday', progress: 60 },
  { id: '4', name: 'Pre-Colonial Trade Routes', type: 'animation', thumbnail: '✨', updatedAt: '2 days ago', progress: 40 },
  { id: '5', name: 'Luba Empire Script', type: 'script', thumbnail: '📝', updatedAt: '3 days ago', progress: 90 },
];

export const stats: Stat[] = [
  { label: 'Total Views', value: '124.5K', change: '+12.3%', positive: true },
  { label: 'Exports', value: '847', change: '+8.1%', positive: true },
  { label: 'Sales', value: '$2,340', change: '+23.5%', positive: true },
  { label: 'Subscribers', value: '3,210', change: '+5.7%', positive: true },
];

export const timelineEvents: TimelineEvent[] = [
  { year: '1390', title: 'Kingdom of Kongo Founded', description: 'Lukeni lua Nimi establishes the Kingdom of Kongo, unifying several smaller states along the Congo River into one of Africa\'s most powerful kingdoms.', category: 'kingdom' },
  { year: '1482', title: 'Portuguese Arrival', description: 'Diogo Cão reaches the mouth of the Congo River, marking the beginning of European contact with the Kingdom of Kongo.', category: 'trade' },
  { year: '1506', title: 'Afonso I\'s Reign Begins', description: 'Mvemba a Nzinga (Afonso I) becomes king and attempts to modernize the Kongo while navigating Portuguese influence.', category: 'kingdom' },
  { year: '1885', title: 'Congo Free State', description: 'The Berlin Conference grants King Leopold II personal control over the Congo, beginning one of history\'s most brutal colonial regimes.', category: 'colonial' },
  { year: '1886', title: 'Boma Becomes Capital', description: 'Boma is established as the capital of the Congo Free State, becoming the administrative center of the colonial territory.', category: 'colonial' },
  { year: '1908', title: 'Belgian Congo', description: 'Belgium annexes the Congo Free State following international outrage over Leopold\'s brutal exploitation of the Congolese people.', category: 'colonial' },
  { year: '1960', title: 'Independence', description: 'The Democratic Republic of the Congo gains independence on June 30th. Patrice Lumumba becomes the first Prime Minister.', category: 'independence' },
  { year: '2024', title: 'Digital Renaissance', description: 'Congolese creators are reclaiming their narrative through digital media, art, and storytelling — preserving and sharing their rich heritage.', category: 'culture' },
];

export const marketplaceItems: MarketplaceItem[] = [
  { id: '1', title: 'Cinematic African Landscape Prompts', type: 'prompt', price: '$4.99', rating: 4.9, sales: 234, author: 'King Studio' },
  { id: '2', title: 'Documentary Intro Template', type: 'template', price: '$12.99', rating: 4.8, sales: 189, author: 'King Studio' },
  { id: '3', title: 'Traditional Congolese Rhythms Pack', type: 'music', price: '$9.99', rating: 4.7, sales: 156, author: 'King Studio' },
  { id: '4', title: 'Historical Photo Restoration Preset', type: 'preset', price: '$7.99', rating: 4.9, sales: 312, author: 'King Studio' },
  { id: '5', title: 'Epic Narration Voice Prompts', type: 'prompt', price: '$3.99', rating: 4.6, sales: 98, author: 'King Studio' },
  { id: '6', title: 'Social Media Story Templates', type: 'template', price: '$8.99', rating: 4.8, sales: 445, author: 'King Studio' },
];

export const galleryImages = [
  { id: '1', title: 'Boma Colonial Architecture', emoji: '🏛️', era: '1890s' },
  { id: '2', title: 'Congo River Trading Post', emoji: '⛵', era: '1900s' },
  { id: '3', title: 'Kingdom of Kongo Artifacts', emoji: '👑', era: '1400s' },
  { id: '4', title: 'Independence Day Celebrations', emoji: '🎉', era: '1960' },
  { id: '5', title: 'Traditional Kongo Masks', emoji: '🎭', era: '1500s' },
  { id: '6', title: 'Luba Kingdom Royal Court', emoji: '🏰', era: '1600s' },
];

export const studioTools = [
  { id: 'image', name: 'Image Generator', icon: '🖼️', description: 'Create stunning visuals from text prompts', color: 'from-amber-900/30 to-yellow-900/20' },
  { id: 'video', name: 'Video Creator', icon: '🎬', description: 'Generate cinematic video sequences', color: 'from-red-900/30 to-orange-900/20' },
  { id: 'music', name: 'Music Composer', icon: '🎵', description: 'Compose original soundtracks & beats', color: 'from-purple-900/30 to-pink-900/20' },
  { id: 'voice', name: 'Voice-Over', icon: '🎙️', description: 'Text-to-speech narration engine', color: 'from-blue-900/30 to-cyan-900/20' },
  { id: 'script', name: 'Script Writer', icon: '📝', description: 'AI-powered script & story writing', color: 'from-green-900/30 to-emerald-900/20' },
  { id: 'animation', name: 'Animation', icon: '✨', description: 'Create smooth motion graphics', color: 'from-indigo-900/30 to-violet-900/20' },
  { id: 'storyboard', name: 'Storyboard', icon: '🎨', description: 'Visual story planning & boards', color: 'from-teal-900/30 to-cyan-900/20' },
  { id: 'idea', name: 'Idea Generator', icon: '💡', description: 'Brainstorm creative concepts', color: 'from-yellow-900/30 to-amber-900/20' },
];

export const kingResponses = [
  "I've drafted a compelling opening sequence for your documentary. The narrative starts with an aerial view of the Congo River, transitioning into historical imagery of the Kingdom of Kongo...",
  "Here's a creative concept: A 3-part series exploring the untold stories of Boma city, from its role as a trading hub to its significance in Congolese independence...",
  "I suggest using warm, golden color grading for the historical segments and cooler tones for the modern-day footage. This creates a visual contrast that emphasizes the journey through time...",
  "For your TikTok content, I recommend 60-second clips focusing on 'Did You Know?' facts about African kingdoms. These tend to get high engagement and shares...",
  "I've generated 5 prompt variations for your AI image generation. Each one captures a different aspect of pre-colonial Congolese architecture and daily life...",
];
