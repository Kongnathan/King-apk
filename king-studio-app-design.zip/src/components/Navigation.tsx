import { Home, Wand2, FolderKanban, BookOpen, ShoppingBag } from 'lucide-react';
import type { Screen } from '../types';

interface NavigationProps {
  activeScreen: Screen;
  onNavigate: (screen: Screen) => void;
}

export function Navigation({ activeScreen, onNavigate }: NavigationProps) {
  const items: { screen: Screen; label: string; icon: typeof Home }[] = [
    { screen: 'dashboard', label: 'Home', icon: Home },
    { screen: 'studio', label: 'Studio', icon: Wand2 },
    { screen: 'projects', label: 'Projects', icon: FolderKanban },
    { screen: 'history', label: 'History', icon: BookOpen },
    { screen: 'marketplace', label: 'Market', icon: ShoppingBag },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 glass border-t border-king-border">
      <div className="max-w-lg mx-auto flex items-center justify-around px-2 py-2">
        {items.map(({ screen, label, icon: Icon }) => {
          const isActive = activeScreen === screen;
          return (
            <button
              key={screen}
              onClick={() => onNavigate(screen)}
              className={`flex flex-col items-center gap-1 py-1.5 px-3 rounded-xl transition-all ${
                isActive ? 'text-king-gold' : 'text-king-muted'
              }`}
            >
              <div className={`relative p-1.5 rounded-lg transition-all ${isActive ? 'bg-king-gold/10' : ''}`}>
                <Icon className="w-5 h-5" strokeWidth={isActive ? 2.5 : 1.5} />
                {isActive && (
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-king-gold rounded-full" />
                )}
              </div>
              <span className={`text-[10px] font-medium ${isActive ? 'text-king-gold' : ''}`}>
                {label}
              </span>
            </button>
          );
        })}
      </div>
      {/* Safe area for mobile */}
      <div className="h-[env(safe-area-inset-bottom)]" />
    </nav>
  );
}
