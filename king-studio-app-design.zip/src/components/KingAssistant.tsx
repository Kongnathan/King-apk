import { useState, useRef, useEffect } from 'react';
import { X, Send, Sparkles, Crown, Lightbulb, Wand2, FileText, Mic } from 'lucide-react';
import type { ChatMessage } from '../types';
import { kingResponses } from '../data';

interface KingAssistantProps {
  isOpen: boolean;
  onClose: () => void;
}

export function KingAssistant({ isOpen, onClose }: KingAssistantProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '0',
      role: 'assistant',
      content: "Welcome to King Studio! 👑\n\nI'm King, your AI creative assistant. I can help you with:\n\n• Writing scripts & prompts\n• Generating creative ideas\n• Planning content strategies\n• Historical research on African heritage\n\nWhat would you like to create today?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 300);
    }
  }, [isOpen]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const response = kingResponses[Math.floor(Math.random() * kingResponses.length)];
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1500 + Math.random() * 1500);
  };

  const quickActions = [
    { icon: Lightbulb, label: 'Generate Ideas', prompt: 'Give me 5 creative ideas for a documentary about Congo history' },
    { icon: FileText, label: 'Write Script', prompt: 'Write a compelling opening script for a documentary about Boma city' },
    { icon: Wand2, label: 'Create Prompt', prompt: 'Create a cinematic image prompt for the Kingdom of Kongo royal court' },
    { icon: Mic, label: 'Voice Script', prompt: 'Write a narration script about the Congo River for a voice-over' },
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      {/* Chat Panel */}
      <div className="relative flex flex-col h-full bg-king-black animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-king-border bg-king-dark/80 backdrop-blur-xl sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 gold-gradient rounded-xl flex items-center justify-center">
              <Crown className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="font-bold text-white text-sm">King AI</h2>
              <div className="flex items-center gap-1">
                <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full" />
                <span className="text-[10px] text-emerald-400">Online</span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-king-card rounded-lg flex items-center justify-center hover:bg-king-hover transition-colors"
          >
            <X className="w-4 h-4 text-king-muted" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-3.5 ${
                  msg.role === 'user'
                    ? 'gold-gradient text-black rounded-br-md'
                    : 'bg-king-card border border-king-border text-white rounded-bl-md'
                }`}
              >
                {msg.role === 'assistant' && (
                  <div className="flex items-center gap-1.5 mb-2">
                    <Sparkles className="w-3 h-3 text-king-gold" />
                    <span className="text-[10px] text-king-gold font-medium">King AI</span>
                  </div>
                )}
                <p className={`text-sm leading-relaxed whitespace-pre-wrap ${
                  msg.role === 'user' ? 'text-black' : 'text-white/85'
                }`}>
                  {msg.content}
                </p>
                <p className={`text-[10px] mt-2 ${
                  msg.role === 'user' ? 'text-black/50' : 'text-king-muted'
                }`}>
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-king-card border border-king-border rounded-2xl rounded-bl-md px-4 py-3">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-king-gold rounded-full" style={{ animation: 'typing 1.4s ease-in-out infinite' }} />
                  <div className="w-2 h-2 bg-king-gold rounded-full" style={{ animation: 'typing 1.4s ease-in-out 0.2s infinite' }} />
                  <div className="w-2 h-2 bg-king-gold rounded-full" style={{ animation: 'typing 1.4s ease-in-out 0.4s infinite' }} />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Actions */}
        {messages.length <= 1 && (
          <div className="px-4 pb-2">
            <div className="grid grid-cols-2 gap-2">
              {quickActions.map(({ icon: Icon, label, prompt }) => (
                <button
                  key={label}
                  onClick={() => { setInput(prompt); }}
                  className="bg-king-card border border-king-border rounded-xl p-3 text-left hover:border-king-gold/30 transition-colors flex items-center gap-2"
                >
                  <Icon className="w-4 h-4 text-king-gold flex-shrink-0" />
                  <span className="text-xs text-king-muted">{label}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="p-4 border-t border-king-border bg-king-dark/80 backdrop-blur-xl">
          <div className="flex items-center gap-2">
            <div className="flex-1 bg-king-card border border-king-border rounded-xl flex items-center">
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask King anything..."
                className="flex-1 bg-transparent text-sm text-white placeholder:text-king-muted/50 px-4 py-3 outline-none"
              />
            </div>
            <button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="w-11 h-11 gold-gradient rounded-xl flex items-center justify-center disabled:opacity-40 active:scale-90 transition-transform flex-shrink-0"
            >
              <Send className="w-4 h-4 text-black" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
