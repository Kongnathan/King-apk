import { useState, useCallback } from 'react';
import { Crown, Bell, Settings, Search } from 'lucide-react';
import type { Screen } from './types';
import { Dashboard } from './screens/Dashboard';
import { AIStudio } from './screens/AIStudio';
import { Projects } from './screens/Projects';
import { History } from './screens/History';
import { Marketplace } from './screens/Marketplace';
import { Navigation } from './components/Navigation';
import { KingAssistant } from './components/KingAssistant';

export function App() {
  const [activeScreen, setActiveScreen] = useState<Screen>('dashboard');
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const handleNavigate = useCallback((screen: Screen) => {
    setActiveScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const notifications = [
    { id: 1, text: 'Your "Boma City" export is complete', time: '2m ago', unread: true },
    { id: 2, text: 'New sale: Documentary Intro Template', time: '1h ago', unread: true },
    { id: 3, text: 'King AI has new capabilities!', time: '3h ago', unread: false },
    { id: 4, text: '"Congo Soundtrack" processing finished', time: '5h ago', unread: false },
  ];

  const screenTitles: Record<Screen, string> = {
    dashboard: '',
    studio: 'AI Studio',
    projects: 'Projects',
    history: 'History',
    marketplace: 'Market',
  };

  return (
    <div className="min-h-screen bg-king-black text-white max-w-lg mx-auto relative">
      {/* Status Bar Spacer */}
      <div className="h-[env(safe-area-inset-top)]" />

      {/* Top Bar */}
      <header className="sticky top-0 z-30 glass border-b border-king-border">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 gold-gradient rounded-xl flex items-center justify-center shadow-lg shadow-king-gold/20">
              <Crown className="w-4.5 h-4.5 text-black" />
            </div>
            {activeScreen === 'dashboard' ? (
              <div>
                <h1 className="text-sm font-bold gold-text">KING STUDIO</h1>
                <p className="text-[10px] text-king-muted -mt-0.5">AI Creator Platform</p>
              </div>
            ) : (
              <h1 className="text-sm font-bold text-white">{screenTitles[activeScreen]}</h1>
            )}
          </div>
          <div className="flex items-center gap-1.5">
            <button className="w-9 h-9 bg-king-card border border-king-border rounded-xl flex items-center justify-center hover:bg-king-hover transition-colors">
              <Search className="w-4 h-4 text-king-muted" />
            </button>
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="w-9 h-9 bg-king-card border border-king-border rounded-xl flex items-center justify-center hover:bg-king-hover transition-colors relative"
              >
                <Bell className="w-4 h-4 text-king-muted" />
                <div className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-king-gold rounded-full border-2 border-king-black" />
              </button>

              {/* Notifications Dropdown */}
              {showNotifications && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowNotifications(false)} />
                  <div className="absolute right-0 top-11 w-72 bg-king-card border border-king-border rounded-2xl shadow-2xl shadow-black/50 z-50 animate-scale-in overflow-hidden">
                    <div className="p-3 border-b border-king-border flex items-center justify-between">
                      <p className="text-xs font-semibold text-white">Notifications</p>
                      <span className="text-[10px] text-king-gold bg-king-gold/10 px-2 py-0.5 rounded-full">2 new</span>
                    </div>
                    <div className="max-h-64 overflow-y-auto">
                      {notifications.map((notif) => (
                        <div
                          key={notif.id}
                          className={`px-3 py-3 border-b border-king-border/50 hover:bg-king-hover transition-colors cursor-pointer ${
                            notif.unread ? 'bg-king-gold/5' : ''
                          }`}
                        >
                          <div className="flex items-start gap-2">
                            {notif.unread && (
                              <div className="w-1.5 h-1.5 bg-king-gold rounded-full mt-1.5 flex-shrink-0" />
                            )}
                            <div>
                              <p className="text-xs text-white leading-relaxed">{notif.text}</p>
                              <p className="text-[10px] text-king-muted mt-1">{notif.time}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
            <button className="w-9 h-9 bg-king-card border border-king-border rounded-xl flex items-center justify-center hover:bg-king-hover transition-colors">
              <Settings className="w-4 h-4 text-king-muted" />
            </button>
          </div>
        </div>
      </header>

      {/* Screen Content */}
      <main className="min-h-[calc(100vh-60px)] pt-2">
        {activeScreen === 'dashboard' && (
          <Dashboard
            onOpenAssistant={() => setAssistantOpen(true)}
            onNavigate={handleNavigate}
          />
        )}
        {activeScreen === 'studio' && (
          <AIStudio onOpenAssistant={() => setAssistantOpen(true)} />
        )}
        {activeScreen === 'projects' && <Projects />}
        {activeScreen === 'history' && <History />}
        {activeScreen === 'marketplace' && <Marketplace />}
      </main>

      {/* Floating King Button */}
      {!assistantOpen && (
        <button
          onClick={() => setAssistantOpen(true)}
          className="fixed bottom-24 right-4 z-30 w-14 h-14 gold-gradient rounded-full flex items-center justify-center shadow-lg shadow-king-gold/30 animate-pulse-gold active:scale-90 transition-transform"
        >
          <Crown className="w-6 h-6 text-black" />
        </button>
      )}

      {/* Bottom Navigation */}
      <Navigation activeScreen={activeScreen} onNavigate={handleNavigate} />

      {/* King AI Assistant */}
      <KingAssistant isOpen={assistantOpen} onClose={() => setAssistantOpen(false)} />
    </div>
  );
}
