export type Screen = 'dashboard' | 'studio' | 'projects' | 'history' | 'marketplace';

export interface Project {
  id: string;
  name: string;
  type: 'video' | 'image' | 'audio' | 'script' | 'animation';
  thumbnail: string;
  updatedAt: string;
  progress: number;
}

export interface Stat {
  label: string;
  value: string;
  change: string;
  positive: boolean;
}

export interface TimelineEvent {
  year: string;
  title: string;
  description: string;
  category: 'kingdom' | 'trade' | 'culture' | 'colonial' | 'independence';
}

export interface MarketplaceItem {
  id: string;
  title: string;
  type: 'prompt' | 'template' | 'music' | 'preset';
  price: string;
  rating: number;
  sales: number;
  author: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}
