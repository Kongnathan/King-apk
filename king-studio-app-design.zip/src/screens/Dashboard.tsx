import { Plus, Sparkles, TrendingUp, ArrowUpRight, Play, Clock, Zap } from 'lucide-react';
import { stats, recentProjects } from '../data';

interface DashboardProps {
  onOpenAssistant: () => void;
  onNavigate: (screen: 'studio' | 'projects') => void;
}

export function Dashboard({ onOpenAssistant, onNavigate }: DashboardProps) {
  const typeColors: Record<string, string> = {
    video: 'bg-red-500/20 text-red-400',
    image: 'bg-blue-500/20 text-blue-400',
    audio: 'bg-purple-500/20 text-purple-400',
    script: 'bg-green-500/20 text-green-400',
    animation: 'bg-amber-500/20 text-amber-400',
  };

  return (
    <div className="px-4 pb-28 pt-2 space-y-6">
      {/* Header */}
      <div className="animate-fade-in">
        <p className="text-king-muted text-sm">Welcome back</p>
        <h1 className="text-2xl font-bold mt-1">
          <span className="gold-text">King</span> Studio
        </h1>
      </div>

      {/* Quick Actions */}
      <div className="flex gap-3 animate-fade-in stagger-1" style={{ opacity: 0 }}>
        <button
          onClick={() => onNavigate('studio')}
          className="flex-1 gold-gradient rounded-2xl p-4 flex items-center gap-3 active:scale-95 transition-transform"
        >
          <div className="w-10 h-10 bg-black/20 rounded-xl flex items-center justify-center">
            <Plus className="w-5 h-5 text-black" />
          </div>
          <div className="text-left">
            <p className="font-semibold text-black text-sm">Quick Create</p>
            <p className="text-black/60 text-xs">New project</p>
          </div>
        </button>
        <button
          onClick={onOpenAssistant}
          className="flex-1 bg-king-card border border-king-border rounded-2xl p-4 flex items-center gap-3 card-hover active:scale-95 transition-transform"
        >
          <div className="w-10 h-10 bg-king-gold/10 rounded-xl flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-king-gold" />
          </div>
          <div className="text-left">
            <p className="font-semibold text-white text-sm">Ask King</p>
            <p className="text-king-muted text-xs">AI Assistant</p>
          </div>
        </button>
      </div>

      {/* Stats Grid */}
      <div className="animate-fade-in stagger-2" style={{ opacity: 0 }}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-king-gold" />
            Analytics
          </h2>
          <span className="text-xs text-king-muted">Last 30 days</span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {stats.map((stat, i) => (
            <div
              key={stat.label}
              className={`bg-king-card border border-king-border rounded-2xl p-4 card-hover stagger-${i + 1}`}
            >
              <p className="text-king-muted text-xs mb-1">{stat.label}</p>
              <p className="text-xl font-bold text-white">{stat.value}</p>
              <div className="flex items-center gap-1 mt-1">
                <ArrowUpRight className="w-3 h-3 text-emerald-400" />
                <span className="text-xs text-emerald-400">{stat.change}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Creative Inspiration */}
      <div className="animate-fade-in stagger-3" style={{ opacity: 0 }}>
        <div className="bg-gradient-to-r from-king-gold/10 via-king-card to-king-card border border-king-gold/20 rounded-2xl p-4 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-king-gold/5 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-4 h-4 text-king-gold" />
              <span className="text-xs text-king-gold font-medium">Daily Inspiration</span>
            </div>
            <p className="text-sm text-white/80 leading-relaxed">
              "Every great documentary begins with a single story waiting to be told. The Congo's history is a goldmine of untold narratives."
            </p>
            <button
              onClick={onOpenAssistant}
              className="mt-3 text-xs text-king-gold font-medium flex items-center gap-1"
            >
              Generate ideas with King <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Recent Projects */}
      <div className="animate-fade-in stagger-4" style={{ opacity: 0 }}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-king-gold" />
            Recent Projects
          </h2>
          <button onClick={() => onNavigate('projects')} className="text-xs text-king-gold font-medium">
            View All
          </button>
        </div>
        <div className="space-y-3">
          {recentProjects.map((project) => (
            <div
              key={project.id}
              className="bg-king-card border border-king-border rounded-2xl p-4 flex items-center gap-4 card-hover active:scale-[0.98] transition-transform cursor-pointer"
            >
              <div className="w-12 h-12 bg-king-surface rounded-xl flex items-center justify-center text-xl">
                {project.thumbnail}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-white text-sm truncate">{project.name}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${typeColors[project.type]}`}>
                    {project.type}
                  </span>
                  <span className="text-xs text-king-muted">{project.updatedAt}</span>
                </div>
                <div className="mt-2 h-1 bg-king-surface rounded-full overflow-hidden">
                  <div
                    className="h-full gold-gradient rounded-full transition-all duration-500"
                    style={{ width: `${project.progress}%` }}
                  />
                </div>
              </div>
              <button className="w-8 h-8 bg-king-surface rounded-lg flex items-center justify-center hover:bg-king-hover transition-colors">
                <Play className="w-3 h-3 text-king-gold fill-king-gold" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
