import { useState } from 'react';
import { Clock, MapPin, Camera, Film, Wifi, WifiOff, ChevronRight, Globe, BookOpen } from 'lucide-react';
import { timelineEvents, galleryImages } from '../data';

type HistoryTab = 'timeline' | 'map' | 'gallery' | 'docs';

export function History() {
  const [activeTab, setActiveTab] = useState<HistoryTab>('timeline');
  const [offlineMode, setOfflineMode] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categoryColors: Record<string, { bg: string; text: string; label: string }> = {
    kingdom: { bg: 'bg-amber-500/20', text: 'text-amber-400', label: 'Kingdom' },
    trade: { bg: 'bg-blue-500/20', text: 'text-blue-400', label: 'Trade' },
    culture: { bg: 'bg-purple-500/20', text: 'text-purple-400', label: 'Culture' },
    colonial: { bg: 'bg-red-500/20', text: 'text-red-400', label: 'Colonial' },
    independence: { bg: 'bg-emerald-500/20', text: 'text-emerald-400', label: 'Independence' },
  };

  const filteredEvents = selectedCategory === 'all'
    ? timelineEvents
    : timelineEvents.filter(e => e.category === selectedCategory);

  const docs = [
    { title: 'The Rise and Fall of Kongo', duration: '12 min', type: 'Mini Documentary', emoji: '🎬' },
    { title: 'Boma: Gateway of the Congo', duration: '8 min', type: 'Short Film', emoji: '🏛️' },
    { title: 'Trade Routes of Central Africa', duration: '15 min', type: 'Documentary', emoji: '⛵' },
    { title: 'Independence Day: June 30, 1960', duration: '10 min', type: 'Historical', emoji: '🎉' },
    { title: 'Art & Culture of the Kongo People', duration: '18 min', type: 'Cultural', emoji: '🎭' },
  ];

  const mapLocations = [
    { name: 'Boma', desc: 'Historic capital of Congo Free State', x: 52, y: 48, emoji: '🏛️' },
    { name: 'Mbanza-Kongo', desc: 'Capital of the Kingdom of Kongo', x: 42, y: 38, emoji: '👑' },
    { name: 'Kinshasa', desc: 'Modern capital of DR Congo', x: 58, y: 42, emoji: '🏙️' },
    { name: 'Kisangani', desc: 'Stanley Falls station', x: 72, y: 30, emoji: '🌊' },
    { name: 'Lubumbashi', desc: 'Mining capital of Katanga', x: 78, y: 68, emoji: '⛏️' },
    { name: 'Matadi', desc: 'Major port on Congo River', x: 48, y: 50, emoji: '⚓' },
  ];

  return (
    <div className="px-4 pb-28 pt-2 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between animate-fade-in">
        <div>
          <h1 className="text-2xl font-bold text-white">History & Archive</h1>
          <p className="text-king-muted text-sm mt-1">African Heritage Collection</p>
        </div>
        <button
          onClick={() => setOfflineMode(!offlineMode)}
          className={`p-2 rounded-xl border transition-all ${
            offlineMode
              ? 'bg-king-gold/20 border-king-gold/30 text-king-gold'
              : 'bg-king-card border-king-border text-king-muted'
          }`}
        >
          {offlineMode ? <WifiOff className="w-4 h-4" /> : <Wifi className="w-4 h-4" />}
        </button>
      </div>

      {offlineMode && (
        <div className="bg-king-gold/10 border border-king-gold/20 rounded-xl p-3 flex items-center gap-2 animate-fade-in">
          <WifiOff className="w-4 h-4 text-king-gold flex-shrink-0" />
          <p className="text-xs text-king-gold">Offline mode — Viewing cached content</p>
        </div>
      )}

      {/* Tabs */}
      <div className="animate-fade-in stagger-1" style={{ opacity: 0 }}>
        <div className="flex gap-1 bg-king-card border border-king-border rounded-xl p-1">
          {([
            { key: 'timeline', label: 'Timeline', icon: Clock },
            { key: 'map', label: 'Map', icon: MapPin },
            { key: 'gallery', label: 'Gallery', icon: Camera },
            { key: 'docs', label: 'Docs', icon: Film },
          ] as const).map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`flex-1 py-2 rounded-lg text-xs font-medium flex items-center justify-center gap-1 transition-all ${
                activeTab === key
                  ? 'gold-gradient text-black'
                  : 'text-king-muted hover:text-white'
              }`}
            >
              <Icon className="w-3 h-3" /> {label}
            </button>
          ))}
        </div>
      </div>

      {/* Timeline Tab */}
      {activeTab === 'timeline' && (
        <div className="space-y-4 animate-fade-in">
          {/* Category Filters */}
          <div className="flex gap-2 overflow-x-auto pb-1">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`text-xs px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
                selectedCategory === 'all'
                  ? 'bg-king-gold/20 text-king-gold border border-king-gold/30'
                  : 'bg-king-card border border-king-border text-king-muted'
              }`}
            >
              All Eras
            </button>
            {Object.entries(categoryColors).map(([key, val]) => (
              <button
                key={key}
                onClick={() => setSelectedCategory(key)}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
                  selectedCategory === key
                    ? `${val.bg} ${val.text} border border-current/30`
                    : 'bg-king-card border border-king-border text-king-muted'
                }`}
              >
                {val.label}
              </button>
            ))}
          </div>

          {/* Timeline */}
          <div className="relative">
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-king-border" />
            <div className="space-y-4">
              {filteredEvents.map((event, i) => {
                const cat = categoryColors[event.category];
                const isExpanded = selectedEvent === event.year;
                return (
                  <div
                    key={event.year + i}
                    onClick={() => setSelectedEvent(isExpanded ? null : event.year)}
                    className={`relative pl-14 cursor-pointer stagger-${Math.min(i + 1, 6)}`}
                  >
                    <div className={`absolute left-4 top-2 w-5 h-5 rounded-full border-2 border-king-dark flex items-center justify-center ${cat.bg}`}>
                      <div className={`w-2 h-2 rounded-full ${cat.text.replace('text-', 'bg-')}`} />
                    </div>
                    <div className={`bg-king-card border rounded-2xl p-4 transition-all ${
                      isExpanded ? 'border-king-gold/30 shadow-lg shadow-king-gold/5' : 'border-king-border'
                    }`}>
                      <div className="flex items-center justify-between mb-1">
                        <span className={`text-xs font-bold ${cat.text}`}>{event.year}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${cat.bg} ${cat.text}`}>{cat.label}</span>
                      </div>
                      <h3 className="font-semibold text-white text-sm">{event.title}</h3>
                      {isExpanded && (
                        <p className="text-xs text-king-muted mt-2 leading-relaxed animate-fade-in">
                          {event.description}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Map Tab */}
      {activeTab === 'map' && (
        <div className="space-y-4 animate-fade-in">
          <div className="bg-king-card border border-king-border rounded-2xl overflow-hidden">
            {/* Map Visualization */}
            <div className="relative aspect-[4/3] bg-gradient-to-br from-king-surface via-king-card to-king-surface overflow-hidden">
              {/* Africa Shape Suggestion */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-[80%] h-[90%] relative">
                  {/* Simplified continent outline */}
                  <svg viewBox="0 0 100 100" className="w-full h-full opacity-20">
                    <path
                      d="M50,5 L60,8 L65,15 L70,20 L75,18 L80,25 L78,35 L82,45 L80,55 L78,65 L75,72 L70,78 L65,82 L60,88 L55,92 L50,95 L45,90 L40,85 L35,80 L30,72 L28,65 L25,55 L22,45 L25,35 L28,25 L35,15 L40,10 Z"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="0.5"
                      className="text-king-gold"
                    />
                  </svg>
                  {/* Location Markers */}
                  {mapLocations.map((loc) => (
                    <button
                      key={loc.name}
                      className="absolute group"
                      style={{ left: `${loc.x}%`, top: `${loc.y}%`, transform: 'translate(-50%, -50%)' }}
                    >
                      <div className="relative">
                        <div className="w-8 h-8 bg-king-gold/20 border border-king-gold/40 rounded-full flex items-center justify-center animate-pulse-gold text-sm">
                          {loc.emoji}
                        </div>
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 bg-king-dark border border-king-border rounded-lg px-2 py-1 whitespace-nowrap opacity-0 group-hover:opacity-100 group-focus:opacity-100 transition-opacity pointer-events-none z-10">
                          <p className="text-[10px] font-bold text-white">{loc.name}</p>
                          <p className="text-[8px] text-king-muted">{loc.desc}</p>
                        </div>
                      </div>
                    </button>
                  ))}
                  {/* Connection Lines */}
                  <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 100 100">
                    <line x1="52" y1="48" x2="42" y2="38" stroke="rgba(212,168,67,0.15)" strokeWidth="0.3" strokeDasharray="2,2" />
                    <line x1="52" y1="48" x2="58" y2="42" stroke="rgba(212,168,67,0.15)" strokeWidth="0.3" strokeDasharray="2,2" />
                    <line x1="52" y1="48" x2="48" y2="50" stroke="rgba(212,168,67,0.15)" strokeWidth="0.3" strokeDasharray="2,2" />
                    <line x1="58" y1="42" x2="72" y2="30" stroke="rgba(212,168,67,0.15)" strokeWidth="0.3" strokeDasharray="2,2" />
                    <line x1="58" y1="42" x2="78" y2="68" stroke="rgba(212,168,67,0.15)" strokeWidth="0.3" strokeDasharray="2,2" />
                  </svg>
                </div>
              </div>
              {/* Map Label */}
              <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
                <Globe className="w-3 h-3 text-king-gold" />
                <span className="text-[10px] text-king-gold font-medium">Democratic Republic of the Congo</span>
              </div>
            </div>
          </div>

          {/* Location Cards */}
          <div className="space-y-2">
            {mapLocations.map((loc) => (
              <div
                key={loc.name}
                className="bg-king-card border border-king-border rounded-xl p-3 flex items-center gap-3 card-hover"
              >
                <div className="w-10 h-10 bg-king-gold/10 rounded-lg flex items-center justify-center text-lg">
                  {loc.emoji}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-white">{loc.name}</p>
                  <p className="text-xs text-king-muted">{loc.desc}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-king-muted" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Gallery Tab */}
      {activeTab === 'gallery' && (
        <div className="space-y-4 animate-fade-in">
          <div className="flex items-center justify-between">
            <p className="text-sm text-king-muted">{galleryImages.length} items in collection</p>
            <BookOpen className="w-4 h-4 text-king-muted" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            {galleryImages.map((img) => (
              <div
                key={img.id}
                className="bg-king-card border border-king-border rounded-2xl overflow-hidden card-hover cursor-pointer"
              >
                <div className="aspect-square bg-gradient-to-br from-king-surface to-king-hover flex items-center justify-center text-4xl relative">
                  {img.emoji}
                  <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-sm rounded-md px-1.5 py-0.5">
                    <span className="text-[10px] text-king-gold font-medium">{img.era}</span>
                  </div>
                </div>
                <div className="p-3">
                  <p className="text-xs font-medium text-white leading-tight">{img.title}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Docs Tab */}
      {activeTab === 'docs' && (
        <div className="space-y-3 animate-fade-in">
          <p className="text-sm text-king-muted">Mini Documentaries & Films</p>
          {docs.map((doc) => (
            <div
              key={doc.title}
              className="bg-king-card border border-king-border rounded-2xl p-4 flex items-center gap-4 card-hover cursor-pointer"
            >
              <div className="w-14 h-14 bg-king-surface rounded-xl flex items-center justify-center text-2xl">
                {doc.emoji}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-white text-sm truncate">{doc.title}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-king-gold/10 text-king-gold">{doc.type}</span>
                  <span className="text-xs text-king-muted">{doc.duration}</span>
                </div>
              </div>
              <div className="w-8 h-8 bg-king-gold/10 rounded-full flex items-center justify-center">
                <Film className="w-4 h-4 text-king-gold" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
