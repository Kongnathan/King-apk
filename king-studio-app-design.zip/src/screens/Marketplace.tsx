import { useState } from 'react';
import { Star, ShoppingCart, Download, Crown, TrendingUp, Package, Search, Filter } from 'lucide-react';
import { marketplaceItems } from '../data';

type MarketTab = 'browse' | 'selling' | 'subscriptions';
type FilterType = 'all' | 'prompt' | 'template' | 'music' | 'preset';

export function Marketplace() {
  const [activeTab, setActiveTab] = useState<MarketTab>('browse');
  const [filter, setFilter] = useState<FilterType>('all');

  const filteredItems = filter === 'all'
    ? marketplaceItems
    : marketplaceItems.filter(i => i.type === filter);

  const typeEmojis: Record<string, string> = {
    prompt: '💬',
    template: '📐',
    music: '🎵',
    preset: '🎨',
  };

  const typeColors: Record<string, string> = {
    prompt: 'bg-blue-500/20 text-blue-400',
    template: 'bg-purple-500/20 text-purple-400',
    music: 'bg-pink-500/20 text-pink-400',
    preset: 'bg-amber-500/20 text-amber-400',
  };

  const subscriptionPlans = [
    {
      name: 'Creator',
      price: '$9.99/mo',
      features: ['50 AI generations/day', 'Basic templates', '720p exports', 'Email support'],
      popular: false,
      emoji: '⚡',
    },
    {
      name: 'Pro Studio',
      price: '$24.99/mo',
      features: ['Unlimited AI generations', 'All premium templates', '4K HDR exports', 'Priority support', 'Custom branding', 'Cloud storage 100GB'],
      popular: true,
      emoji: '👑',
    },
    {
      name: 'Enterprise',
      price: '$49.99/mo',
      features: ['Everything in Pro', 'API access', 'Team collaboration', 'White label', 'Dedicated support', '1TB cloud storage'],
      popular: false,
      emoji: '🏢',
    },
  ];

  const sellerStats = [
    { label: 'Total Sales', value: '$2,340', icon: TrendingUp },
    { label: 'Items Listed', value: '12', icon: Package },
    { label: 'Downloads', value: '847', icon: Download },
    { label: 'Avg Rating', value: '4.8', icon: Star },
  ];

  return (
    <div className="px-4 pb-28 pt-2 space-y-5">
      {/* Header */}
      <div className="animate-fade-in">
        <h1 className="text-2xl font-bold text-white">Marketplace</h1>
        <p className="text-king-muted text-sm mt-1">Buy, sell & grow your creative empire</p>
      </div>

      {/* Tabs */}
      <div className="animate-fade-in stagger-1" style={{ opacity: 0 }}>
        <div className="flex gap-1 bg-king-card border border-king-border rounded-xl p-1">
          {([
            { key: 'browse', label: 'Browse' },
            { key: 'selling', label: 'My Shop' },
            { key: 'subscriptions', label: 'Plans' },
          ] as const).map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${
                activeTab === key
                  ? 'gold-gradient text-black'
                  : 'text-king-muted hover:text-white'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Browse Tab */}
      {activeTab === 'browse' && (
        <div className="space-y-5 animate-fade-in">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-king-muted" />
            <input
              type="text"
              placeholder="Search prompts, templates, music..."
              className="w-full bg-king-card border border-king-border rounded-xl pl-11 pr-12 py-3 text-sm text-white placeholder:text-king-muted/50 outline-none focus:border-king-gold/30 transition-colors"
            />
            <button className="absolute right-3 top-1/2 -translate-y-1/2 w-7 h-7 bg-king-surface rounded-lg flex items-center justify-center">
              <Filter className="w-3.5 h-3.5 text-king-muted" />
            </button>
          </div>

          {/* Featured Banner */}
          <div className="bg-gradient-to-r from-king-gold/20 via-king-card to-king-card border border-king-gold/20 rounded-2xl p-5 relative overflow-hidden">
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-king-gold/10 rounded-full" />
            <div className="relative">
              <div className="flex items-center gap-2 mb-2">
                <Crown className="w-4 h-4 text-king-gold" />
                <span className="text-xs text-king-gold font-medium">Featured Collection</span>
              </div>
              <h3 className="font-bold text-white">African Heritage Prompt Pack</h3>
              <p className="text-xs text-king-muted mt-1">50+ curated prompts for historical African imagery</p>
              <div className="flex items-center justify-between mt-3">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 text-king-gold fill-king-gold" />
                  ))}
                  <span className="text-xs text-king-muted ml-1">(312)</span>
                </div>
                <span className="gold-text font-bold">$14.99</span>
              </div>
            </div>
          </div>

          {/* Filters */}
          <div className="flex gap-2 overflow-x-auto pb-1">
            {([
              { key: 'all', label: 'All' },
              { key: 'prompt', label: '💬 Prompts' },
              { key: 'template', label: '📐 Templates' },
              { key: 'music', label: '🎵 Music' },
              { key: 'preset', label: '🎨 Presets' },
            ] as { key: FilterType; label: string }[]).map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setFilter(key)}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
                  filter === key
                    ? 'bg-king-gold/20 text-king-gold border border-king-gold/30'
                    : 'bg-king-card border border-king-border text-king-muted'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Items */}
          <div className="space-y-3">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="bg-king-card border border-king-border rounded-2xl p-4 card-hover cursor-pointer"
              >
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 bg-king-surface rounded-xl flex items-center justify-center text-2xl flex-shrink-0">
                    {typeEmojis[item.type]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-white text-sm truncate">{item.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${typeColors[item.type]}`}>
                        {item.type}
                      </span>
                      <span className="text-xs text-king-muted">by {item.author}</span>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 text-king-gold fill-king-gold" />
                        <span className="text-xs text-white">{item.rating}</span>
                        <span className="text-xs text-king-muted">· {item.sales} sales</span>
                      </div>
                      <span className="font-bold text-king-gold text-sm">{item.price}</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <button className="flex-1 bg-king-surface border border-king-border text-white text-xs py-2.5 rounded-xl font-medium hover:bg-king-hover transition-colors flex items-center justify-center gap-1">
                    <ShoppingCart className="w-3 h-3" /> Add to Cart
                  </button>
                  <button className="flex-1 gold-gradient text-black text-xs py-2.5 rounded-xl font-medium active:scale-95 transition-transform flex items-center justify-center gap-1">
                    <Download className="w-3 h-3" /> Buy Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* My Shop Tab */}
      {activeTab === 'selling' && (
        <div className="space-y-5 animate-fade-in">
          {/* Seller Stats */}
          <div className="grid grid-cols-2 gap-3">
            {sellerStats.map(({ label, value, icon: Icon }) => (
              <div key={label} className="bg-king-card border border-king-border rounded-2xl p-4">
                <Icon className="w-4 h-4 text-king-gold mb-2" />
                <p className="text-lg font-bold text-white">{value}</p>
                <p className="text-xs text-king-muted">{label}</p>
              </div>
            ))}
          </div>

          {/* Revenue Chart Placeholder */}
          <div className="bg-king-card border border-king-border rounded-2xl p-4">
            <p className="text-sm font-medium text-white mb-3">Revenue (Last 7 Days)</p>
            <div className="flex items-end gap-2 h-24">
              {[45, 65, 55, 80, 70, 90, 85].map((h, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-1">
                  <div
                    className="w-full gold-gradient rounded-t-md transition-all duration-500"
                    style={{ height: `${h}%` }}
                  />
                  <span className="text-[8px] text-king-muted">
                    {['M', 'T', 'W', 'T', 'F', 'S', 'S'][i]}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Listed Items */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="font-medium text-white text-sm">Your Listings</p>
              <button className="text-xs text-king-gold font-medium">+ Add New</button>
            </div>
            <div className="space-y-2">
              {marketplaceItems.slice(0, 3).map((item) => (
                <div key={item.id} className="bg-king-card border border-king-border rounded-xl p-3 flex items-center gap-3">
                  <div className="w-10 h-10 bg-king-surface rounded-lg flex items-center justify-center text-lg">
                    {typeEmojis[item.type]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate">{item.title}</p>
                    <p className="text-xs text-king-muted">{item.sales} sales · {item.price}</p>
                  </div>
                  <div className="text-xs text-emerald-400 font-medium">Active</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Subscription Plans Tab */}
      {activeTab === 'subscriptions' && (
        <div className="space-y-4 animate-fade-in">
          <div className="text-center mb-2">
            <p className="text-sm text-king-muted">Choose the plan that fits your creative needs</p>
          </div>

          {subscriptionPlans.map((plan) => (
            <div
              key={plan.name}
              className={`bg-king-card border rounded-2xl p-5 relative overflow-hidden ${
                plan.popular ? 'border-king-gold/40 shadow-lg shadow-king-gold/5' : 'border-king-border'
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 right-0 gold-gradient text-black text-[10px] font-bold px-3 py-1 rounded-bl-xl">
                  POPULAR
                </div>
              )}
              <div className="flex items-center gap-3 mb-3">
                <span className="text-2xl">{plan.emoji}</span>
                <div>
                  <h3 className="font-bold text-white">{plan.name}</h3>
                  <p className="gold-text font-bold text-lg">{plan.price}</p>
                </div>
              </div>
              <div className="space-y-2 mb-4">
                {plan.features.map((feature) => (
                  <div key={feature} className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-king-gold/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-1.5 h-1.5 bg-king-gold rounded-full" />
                    </div>
                    <span className="text-xs text-king-muted">{feature}</span>
                  </div>
                ))}
              </div>
              <button
                className={`w-full py-3 rounded-xl text-sm font-medium transition-all active:scale-95 ${
                  plan.popular
                    ? 'gold-gradient text-black'
                    : 'bg-king-surface border border-king-border text-white hover:bg-king-hover'
                }`}
              >
                {plan.popular ? 'Get Started' : 'Choose Plan'}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
