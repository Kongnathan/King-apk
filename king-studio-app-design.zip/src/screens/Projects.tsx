import { useState } from 'react';
import { Folder, Image, FileText, Music, Film, Search, Grid3X3, List, Plus, MoreVertical, Download, Share2, Trash2 } from 'lucide-react';
import { recentProjects } from '../data';

type ViewMode = 'grid' | 'list';
type Filter = 'all' | 'video' | 'image' | 'audio' | 'script' | 'animation';

export function Projects() {
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [filter, setFilter] = useState<Filter>('all');
  const [activeTab, setActiveTab] = useState<'projects' | 'folders' | 'media' | 'notes'>('projects');
  const [contextMenu, setContextMenu] = useState<string | null>(null);

  const filteredProjects = filter === 'all'
    ? recentProjects
    : recentProjects.filter(p => p.type === filter);

  const folders = [
    { name: 'Documentaries', count: 12, icon: '🎬', color: 'bg-red-500/10 border-red-500/20' },
    { name: 'Social Media', count: 24, icon: '📱', color: 'bg-blue-500/10 border-blue-500/20' },
    { name: 'Music & Audio', count: 8, icon: '🎵', color: 'bg-purple-500/10 border-purple-500/20' },
    { name: 'Photography', count: 45, icon: '📸', color: 'bg-amber-500/10 border-amber-500/20' },
    { name: 'Scripts & Drafts', count: 16, icon: '📝', color: 'bg-green-500/10 border-green-500/20' },
    { name: 'Archive', count: 156, icon: '📦', color: 'bg-king-gold/10 border-king-gold/20' },
  ];

  const mediaFiles = [
    { name: 'congo_river_drone.mp4', size: '2.4 GB', type: 'video' },
    { name: 'boma_panorama.jpg', size: '18 MB', type: 'image' },
    { name: 'narration_v3.mp3', size: '45 MB', type: 'audio' },
    { name: 'kongo_artifacts.png', size: '12 MB', type: 'image' },
    { name: 'soundtrack_draft.wav', size: '120 MB', type: 'audio' },
    { name: 'interview_raw.mov', size: '5.1 GB', type: 'video' },
  ];

  const notes = [
    { title: 'Documentary Outline', content: 'Three-part structure focusing on pre-colonial, colonial, and modern Congo...', date: 'Today' },
    { title: 'Interview Questions', content: 'Prepared 15 questions for the historian interview about Boma city...', date: 'Yesterday' },
    { title: 'Location Scouting Notes', content: 'Best spots for aerial footage along the river...', date: '3 days ago' },
    { title: 'Color Grading Reference', content: 'Golden warm tones for historical segments, cool blues for modern...', date: '1 week ago' },
  ];

  const typeIcons: Record<string, React.ReactNode> = {
    video: <Film className="w-4 h-4 text-red-400" />,
    image: <Image className="w-4 h-4 text-blue-400" />,
    audio: <Music className="w-4 h-4 text-purple-400" />,
    script: <FileText className="w-4 h-4 text-green-400" />,
    animation: <span className="text-sm">✨</span>,
  };

  const filterOptions: { key: Filter; label: string }[] = [
    { key: 'all', label: 'All' },
    { key: 'video', label: 'Video' },
    { key: 'image', label: 'Image' },
    { key: 'audio', label: 'Audio' },
    { key: 'script', label: 'Script' },
  ];

  return (
    <div className="px-4 pb-28 pt-2 space-y-5">
      {/* Header */}
      <div className="animate-fade-in">
        <h1 className="text-2xl font-bold text-white">Projects</h1>
        <p className="text-king-muted text-sm mt-1">Manage your creative work</p>
      </div>

      {/* Search */}
      <div className="animate-fade-in stagger-1" style={{ opacity: 0 }}>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-king-muted" />
          <input
            type="text"
            placeholder="Search projects, files, notes..."
            className="w-full bg-king-card border border-king-border rounded-xl pl-11 pr-4 py-3 text-sm text-white placeholder:text-king-muted/50 outline-none focus:border-king-gold/30 transition-colors"
          />
        </div>
      </div>

      {/* Tabs */}
      <div className="animate-fade-in stagger-2" style={{ opacity: 0 }}>
        <div className="flex gap-1 bg-king-card border border-king-border rounded-xl p-1">
          {(['projects', 'folders', 'media', 'notes'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${
                activeTab === tab
                  ? 'gold-gradient text-black'
                  : 'text-king-muted hover:text-white'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Projects Tab */}
      {activeTab === 'projects' && (
        <div className="space-y-4 animate-fade-in">
          {/* Filters & View Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
              {filterOptions.map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => setFilter(key)}
                  className={`text-xs px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
                    filter === key
                      ? 'bg-king-gold/20 text-king-gold border border-king-gold/30'
                      : 'bg-king-card border border-king-border text-king-muted'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="flex gap-1 ml-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-king-gold/20 text-king-gold' : 'text-king-muted'}`}
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-king-gold/20 text-king-gold' : 'text-king-muted'}`}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Projects Grid/List */}
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-2 gap-3">
              {filteredProjects.map((project) => (
                <div
                  key={project.id}
                  className="bg-king-card border border-king-border rounded-2xl overflow-hidden card-hover relative"
                >
                  <div className="aspect-video bg-king-surface flex items-center justify-center text-3xl relative">
                    {project.thumbnail}
                    <div className="absolute bottom-2 right-2">
                      <button
                        onClick={() => setContextMenu(contextMenu === project.id ? null : project.id)}
                        className="w-6 h-6 bg-black/60 rounded-full flex items-center justify-center"
                      >
                        <MoreVertical className="w-3 h-3 text-white" />
                      </button>
                    </div>
                    {contextMenu === project.id && (
                      <div className="absolute bottom-8 right-2 bg-king-card border border-king-border rounded-xl p-1 z-10 animate-scale-in shadow-xl">
                        <button className="flex items-center gap-2 px-3 py-2 text-xs text-white hover:bg-king-hover rounded-lg w-full">
                          <Share2 className="w-3 h-3" /> Export
                        </button>
                        <button className="flex items-center gap-2 px-3 py-2 text-xs text-white hover:bg-king-hover rounded-lg w-full">
                          <Download className="w-3 h-3" /> Download
                        </button>
                        <button className="flex items-center gap-2 px-3 py-2 text-xs text-red-400 hover:bg-red-500/10 rounded-lg w-full">
                          <Trash2 className="w-3 h-3" /> Delete
                        </button>
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <p className="text-xs font-medium text-white truncate">{project.name}</p>
                    <p className="text-[10px] text-king-muted mt-1">{project.updatedAt}</p>
                    <div className="mt-2 h-1 bg-king-surface rounded-full overflow-hidden">
                      <div className="h-full gold-gradient rounded-full" style={{ width: `${project.progress}%` }} />
                    </div>
                  </div>
                </div>
              ))}
              <button className="bg-king-card border border-dashed border-king-border rounded-2xl aspect-[4/3] flex flex-col items-center justify-center gap-2 hover:border-king-gold/30 transition-colors">
                <Plus className="w-6 h-6 text-king-muted" />
                <span className="text-xs text-king-muted">New Project</span>
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredProjects.map((project) => (
                <div
                  key={project.id}
                  className="bg-king-card border border-king-border rounded-xl p-3 flex items-center gap-3 card-hover"
                >
                  <div className="w-10 h-10 bg-king-surface rounded-lg flex items-center justify-center text-lg">
                    {project.thumbnail}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{project.name}</p>
                    <p className="text-xs text-king-muted">{project.updatedAt} · {project.progress}%</p>
                  </div>
                  {typeIcons[project.type]}
                </div>
              ))}
            </div>
          )}

          {/* Export Buttons */}
          <div className="space-y-2">
            <p className="text-xs text-king-muted font-medium">Quick Export</p>
            <div className="flex gap-2">
              <button className="flex-1 bg-king-card border border-king-border rounded-xl p-3 flex items-center gap-2 text-sm text-white hover:border-red-500/30 transition-colors">
                <span className="text-lg">▶️</span> YouTube
              </button>
              <button className="flex-1 bg-king-card border border-king-border rounded-xl p-3 flex items-center gap-2 text-sm text-white hover:border-pink-500/30 transition-colors">
                <span className="text-lg">🎵</span> TikTok
              </button>
              <button className="flex-1 bg-king-card border border-king-border rounded-xl p-3 flex items-center gap-2 text-sm text-white hover:border-blue-500/30 transition-colors">
                <span className="text-lg">📷</span> Reels
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Folders Tab */}
      {activeTab === 'folders' && (
        <div className="space-y-3 animate-fade-in">
          {folders.map((folder) => (
            <div
              key={folder.name}
              className={`bg-king-card border rounded-2xl p-4 flex items-center gap-4 card-hover cursor-pointer ${folder.color}`}
            >
              <div className="w-12 h-12 bg-king-surface rounded-xl flex items-center justify-center text-xl">
                {folder.icon}
              </div>
              <div className="flex-1">
                <p className="font-medium text-white text-sm">{folder.name}</p>
                <p className="text-xs text-king-muted">{folder.count} items</p>
              </div>
              <Folder className="w-4 h-4 text-king-muted" />
            </div>
          ))}
          <button className="w-full bg-king-card border border-dashed border-king-border rounded-2xl p-4 flex items-center justify-center gap-2 text-king-muted hover:border-king-gold/30 transition-colors">
            <Plus className="w-4 h-4" />
            <span className="text-sm">New Folder</span>
          </button>
        </div>
      )}

      {/* Media Library Tab */}
      {activeTab === 'media' && (
        <div className="space-y-3 animate-fade-in">
          <div className="flex items-center justify-between">
            <p className="text-sm text-king-muted">6 files · 7.7 GB total</p>
            <button className="text-xs text-king-gold font-medium">Upload</button>
          </div>
          {mediaFiles.map((file) => (
            <div
              key={file.name}
              className="bg-king-card border border-king-border rounded-xl p-3 flex items-center gap-3 card-hover"
            >
              <div className="w-10 h-10 bg-king-surface rounded-lg flex items-center justify-center">
                {file.type === 'video' ? <Film className="w-4 h-4 text-red-400" /> :
                 file.type === 'image' ? <Image className="w-4 h-4 text-blue-400" /> :
                 <Music className="w-4 h-4 text-purple-400" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white truncate">{file.name}</p>
                <p className="text-xs text-king-muted">{file.size}</p>
              </div>
              <Download className="w-4 h-4 text-king-muted" />
            </div>
          ))}
        </div>
      )}

      {/* Notes Tab */}
      {activeTab === 'notes' && (
        <div className="space-y-3 animate-fade-in">
          {notes.map((note) => (
            <div
              key={note.title}
              className="bg-king-card border border-king-border rounded-2xl p-4 card-hover cursor-pointer"
            >
              <div className="flex items-center justify-between mb-2">
                <p className="font-medium text-white text-sm">{note.title}</p>
                <span className="text-[10px] text-king-muted">{note.date}</span>
              </div>
              <p className="text-xs text-king-muted leading-relaxed line-clamp-2">{note.content}</p>
            </div>
          ))}
          <button className="w-full bg-king-card border border-dashed border-king-border rounded-2xl p-4 flex items-center justify-center gap-2 text-king-muted hover:border-king-gold/30 transition-colors">
            <Plus className="w-4 h-4" />
            <span className="text-sm">New Note</span>
          </button>
        </div>
      )}
    </div>
  );
}
