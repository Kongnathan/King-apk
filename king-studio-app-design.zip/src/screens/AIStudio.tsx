import { useState } from 'react';
import { ArrowRight, Wand2, ChevronDown, Copy, Check, Sparkles } from 'lucide-react';
import { studioTools } from '../data';

export function AIStudio({ onOpenAssistant }: { onOpenAssistant: () => void }) {
  const [activeToolId, setActiveToolId] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState('');
  const [copied, setCopied] = useState(false);

  const activeTool = studioTools.find(t => t.id === activeToolId);

  const handleGenerate = () => {
    if (!prompt.trim()) return;
    setGenerating(true);
    setResult('');
    setTimeout(() => {
      const results: Record<string, string> = {
        image: `🖼️ Prompt Generated:\n\n"${prompt}" — Cinematic wide-angle shot, golden hour lighting, 8K resolution, photorealistic rendering, dramatic composition with depth of field, warm African color palette, inspired by National Geographic photography style.\n\nNegative: blurry, low quality, overexposed\nStyle: Photorealistic\nAspect: 16:9\nSeed: 42891`,
        video: `🎬 Video Sequence:\n\nScene 1: Establishing shot — Slow drone pull-back over the Congo River at dawn\nScene 2: Close-up montage of historical artifacts\nScene 3: Interview setup with warm, natural lighting\nScene 4: B-roll of local architecture and daily life\n\nDuration: 3:45\nFormat: 4K HDR\nMusic: Ambient African percussion`,
        music: `🎵 Composition Brief:\n\nGenre: Cinematic African Fusion\nTempo: 85 BPM\nKey: D minor\nInstruments: Kalimba, Talking Drum, Strings, Ambient Pads\nMood: Reflective, Powerful, Hopeful\nDuration: 4:20\nStructure: Intro → Build → Climax → Gentle Outro`,
        voice: `🎙️ Voice-Over Script:\n\n[Narrator — Deep, Warm Tone]\n\n"Long before the borders were drawn... long before the world knew its name... the Congo basin was home to kingdoms that rivaled any in the world. This is a story of resilience, of beauty, and of a legacy that refuses to be forgotten."\n\nVoice: Baritone, African accent\nPace: Measured, deliberate\nEmotion: Reverent`,
        script: `📝 Script Draft:\n\nTITLE: "${prompt}"\n\nFADE IN:\n\nEXT. CONGO RIVER — SUNRISE\n\nThe camera glides over mist-covered waters. The sound of nature fills the air.\n\nNARRATOR (V.O.)\nIn the heart of Africa, where the great river carves its path through ancient forests, lies a story the world has yet to fully hear.\n\nCUT TO:\n\nINT. MUSEUM — DAY\n\nClose-up of a centuries-old Kongo mask, its features catching the light.`,
        animation: `✨ Animation Sequence:\n\nFrame 1-30: Map unfolds from parchment texture\nFrame 31-60: Trade routes illuminate as golden paths\nFrame 61-90: Kingdom boundaries pulse and expand\nFrame 91-120: Camera zooms into Boma city location\n\nStyle: 2.5D parallax\nDuration: 4 seconds\nEasing: Cubic-bezier\nColor: Gold on dark background`,
        storyboard: `🎨 Storyboard Layout:\n\n[Panel 1] Wide establishing shot — River at dawn\n[Panel 2] Medium shot — Elder speaking to camera\n[Panel 3] Close-up — Hands crafting traditional art\n[Panel 4] Aerial — Modern Boma city skyline\n[Panel 5] Split screen — Past vs Present comparison\n[Panel 6] Final — Text overlay with call-to-action\n\n6 panels, 16:9 ratio each`,
        idea: `💡 Creative Concepts:\n\n1. "Echoes of Kongo" — A 5-part docuseries tracing the Kingdom's influence on modern culture\n\n2. "River of Stories" — Interactive web experience following the Congo River\n\n3. "Boma Reborn" — Short film about the city's transformation\n\n4. "The Golden Thread" — Animated series about African trade routes\n\n5. "Voices Unheard" — Podcast featuring oral histories from Congo elders`,
      };
      setResult(results[activeToolId || 'idea'] || results.idea);
      setGenerating(false);
    }, 2000);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (activeTool) {
    return (
      <div className="px-4 pb-28 pt-2 space-y-5">
        <div className="animate-fade-in">
          <button
            onClick={() => { setActiveToolId(null); setResult(''); setPrompt(''); }}
            className="text-king-muted text-sm mb-2 flex items-center gap-1"
          >
            ← Back to Studio
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-king-card border border-king-border rounded-xl flex items-center justify-center text-2xl">
              {activeTool.icon}
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">{activeTool.name}</h1>
              <p className="text-king-muted text-xs">{activeTool.description}</p>
            </div>
          </div>
        </div>

        {/* Prompt Input */}
        <div className="animate-fade-in stagger-1" style={{ opacity: 0 }}>
          <label className="text-sm text-king-muted mb-2 block">Describe your vision</label>
          <div className="bg-king-card border border-king-border rounded-2xl overflow-hidden">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={`Describe what you want to ${activeTool.id === 'image' ? 'visualize' : activeTool.id === 'music' ? 'compose' : 'create'}...`}
              className="w-full bg-transparent text-white placeholder:text-king-muted/50 p-4 text-sm resize-none h-32 outline-none"
            />
            <div className="flex items-center justify-between p-3 border-t border-king-border">
              <div className="flex gap-2">
                <button className="text-xs bg-king-surface text-king-muted px-3 py-1.5 rounded-lg hover:text-white transition-colors flex items-center gap-1">
                  <ChevronDown className="w-3 h-3" /> Style
                </button>
                <button className="text-xs bg-king-surface text-king-muted px-3 py-1.5 rounded-lg hover:text-white transition-colors flex items-center gap-1">
                  <ChevronDown className="w-3 h-3" /> Format
                </button>
              </div>
              <button
                onClick={handleGenerate}
                disabled={!prompt.trim() || generating}
                className="gold-gradient text-black font-medium text-sm px-5 py-2 rounded-xl flex items-center gap-2 disabled:opacity-50 active:scale-95 transition-transform"
              >
                {generating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4" /> Generate
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Quick Prompts */}
        {!result && (
          <div className="animate-fade-in stagger-2" style={{ opacity: 0 }}>
            <p className="text-xs text-king-muted mb-2">Quick prompts</p>
            <div className="flex flex-wrap gap-2">
              {[
                'Kingdom of Kongo royal court',
                'Congo River at sunset',
                'Traditional Congolese ceremony',
                'Boma city historical',
                'African warrior portrait',
              ].map((q) => (
                <button
                  key={q}
                  onClick={() => setPrompt(q)}
                  className="text-xs bg-king-card border border-king-border px-3 py-2 rounded-xl text-king-muted hover:text-white hover:border-king-gold/30 transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Result */}
        {result && (
          <div className="animate-scale-in">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-king-gold flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> Generated Result
              </p>
              <button
                onClick={handleCopy}
                className="text-xs text-king-muted flex items-center gap-1 hover:text-white transition-colors"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copied ? 'Copied!' : 'Copy'}
              </button>
            </div>
            <div className="bg-king-card border border-king-gold/20 rounded-2xl p-4">
              <pre className="text-sm text-white/80 whitespace-pre-wrap font-sans leading-relaxed">{result}</pre>
            </div>
            <div className="flex gap-2 mt-3">
              <button
                onClick={() => { setResult(''); setPrompt(''); }}
                className="flex-1 bg-king-card border border-king-border text-white text-sm py-3 rounded-xl font-medium active:scale-95 transition-transform"
              >
                New Prompt
              </button>
              <button
                onClick={onOpenAssistant}
                className="flex-1 gold-gradient text-black text-sm py-3 rounded-xl font-medium active:scale-95 transition-transform"
              >
                Refine with King
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="px-4 pb-28 pt-2 space-y-6">
      <div className="animate-fade-in">
        <h1 className="text-2xl font-bold text-white">AI Studio</h1>
        <p className="text-king-muted text-sm mt-1">Create with the power of AI</p>
      </div>

      {/* Featured Tool */}
      <div className="animate-fade-in stagger-1" style={{ opacity: 0 }}>
        <button
          onClick={() => setActiveToolId('idea')}
          className="w-full bg-gradient-to-br from-king-gold/20 via-king-card to-king-card border border-king-gold/20 rounded-2xl p-5 text-left relative overflow-hidden active:scale-[0.98] transition-transform"
        >
          <div className="absolute top-0 right-0 w-40 h-40 bg-king-gold/5 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="relative">
            <div className="w-12 h-12 gold-gradient rounded-xl flex items-center justify-center text-2xl mb-3">
              💡
            </div>
            <h3 className="font-bold text-white text-lg">Idea Generator</h3>
            <p className="text-king-muted text-sm mt-1">
              Brainstorm creative concepts, series ideas, and content strategies
            </p>
            <div className="mt-3 flex items-center gap-1 text-king-gold text-sm font-medium">
              Start Creating <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </button>
      </div>

      {/* Tools Grid */}
      <div className="animate-fade-in stagger-2" style={{ opacity: 0 }}>
        <h2 className="font-semibold text-white mb-3 flex items-center gap-2">
          <Wand2 className="w-4 h-4 text-king-gold" />
          Creation Tools
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {studioTools.filter(t => t.id !== 'idea').map((tool, i) => (
            <button
              key={tool.id}
              onClick={() => setActiveToolId(tool.id)}
              className={`bg-gradient-to-br ${tool.color} border border-king-border rounded-2xl p-4 text-left card-hover active:scale-95 transition-transform stagger-${i + 1}`}
            >
              <div className="text-2xl mb-2">{tool.icon}</div>
              <p className="font-medium text-white text-sm">{tool.name}</p>
              <p className="text-king-muted text-xs mt-1 leading-relaxed">{tool.description}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Pro Tips */}
      <div className="animate-fade-in stagger-4" style={{ opacity: 0 }}>
        <div className="bg-king-card border border-king-border rounded-2xl p-4">
          <p className="text-xs text-king-gold font-medium mb-2">💎 Pro Tip</p>
          <p className="text-sm text-king-muted leading-relaxed">
            Combine multiple tools for maximum impact. Start with the Idea Generator, then use the Script Writer, and finally the Voice-Over tool for a complete production workflow.
          </p>
        </div>
      </div>
    </div>
  );
}
